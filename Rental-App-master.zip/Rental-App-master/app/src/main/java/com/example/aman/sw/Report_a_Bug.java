package com.example.aman.sw;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Report_a_Bug extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_a__bug);
    }
}
